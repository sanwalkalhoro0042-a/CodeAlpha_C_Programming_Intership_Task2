# CodeAlpha Student Management System (C)

A menu-driven C application that manages student records for **CodeAlpha C Programming Internship — Task 3 (High)**. It demonstrates structures and file handling to keep records between program runs.

## Overview

Each student record contains an ID, name, age, department, and CGPA. The program lets the user add, delete, update, search, and display records. Student data is stored locally in a binary file named `students.dat`.

## Features

- Add student records
- Delete a record after confirmation
- Update a student's details while keeping the ID unchanged
- Search by student ID
- Display all stored records in a table
- Prevent duplicate student IDs
- Validate common invalid inputs and field ranges
- Store records locally so they remain available after restarting the program
- Use temporary and backup files when rewriting the database for updates or deletions

## Student record fields

| Field | Type | Purpose |
|---|---|---|
| `id` | `int` | Unique positive student ID |
| `name` | `char[]` | Student name |
| `age` | `int` | Age from 1 to 120 |
| `department` | `char[]` | Department name |
| `cgpa` | `double` | CGPA from 0.00 to 4.00 |

The CGPA range is set to a 4.00 scale in this version; adjust the validation if your institution uses another scale.

## Concepts demonstrated

- `struct` and `typedef`
- Functions and modular program design
- File operations using `fopen()`, `fread()`, `fwrite()`, `fclose()`, `rename()`, and `remove()`
- Binary file access
- Searching and rewriting records
- Input validation and error handling
- Menu-driven control flow with `switch`

## Requirements

- A C compiler that supports C11, such as GCC
- A terminal or command prompt (or a C IDE configured with a compiler)
- Write permission in the directory where the program is run, because the program creates its database and temporary files there

## Project files

```text
CodeAlpha_StudentManagementSystem/
├── README.md
└── Student_Management.c
```

When you run the program, it creates `students.dat`. Temporary or backup files may appear while records are being updated or deleted. Keep the data file if you want to retain the records.

## Compile and run

Compile with GCC:

```bash
gcc -std=c11 -Wall -Wextra -Wpedantic -Wconversion -Wshadow Student_Management.c -o student_management
```

Run on Linux or macOS:

```bash
./student_management
```

On Windows with GCC:

```bash
student_management.exe
```

## Menu options

```text
1. Add Student
2. Delete Student
3. Update Student
4. Search Student
5. Display All Students
0. Exit
```

## Test checklist

- [ ] Add a student with a new ID
- [ ] Try adding a duplicate ID
- [ ] Search for an existing ID
- [ ] Search for a non-existent ID
- [ ] Update a student's details
- [ ] Cancel a deletion and verify that the record remains
- [ ] Delete a record and display all remaining records
- [ ] Restart the program and confirm records are still stored
- [ ] Test invalid menu choices and non-numeric input

## Storage note

This educational version writes the raw binary representation of a C `Student` structure. Binary structure files are convenient for a small local project, but they are not guaranteed to be portable across different compilers, architectures, or changed structure definitions. Do not manually edit `students.dat` as a text file.

## Learning references

- [ISO/IEC 9899:2024 — C programming language standard](https://www.iso.org/standard/82075.html)
- [ISO C working group WG14](https://open-std.org/jtc1/sc22/wg14/)
- [GNU C manual: Structures](https://www.gnu.org/software/c-intro-and-ref/manual/html_node/Structures.html)
- [cppreference: `fopen`](https://en.cppreference.com/w/c/io/fopen)
- [cppreference: `fread`](https://en.cppreference.com/w/c/io/fread)
- [cppreference: `fwrite`](https://en.cppreference.com/w/c/io/fwrite)
- [cppreference: `rename`](https://en.cppreference.com/w/c/io/rename)

## Internship task

**Organization:** CodeAlpha  
**Domain:** C Programming  
**Task:** Task 3 — Student Management System

---

This is an educational internship project. Review and test the source code with your own compiler before submission.
