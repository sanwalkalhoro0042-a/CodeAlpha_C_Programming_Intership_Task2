# CodeAlpha Basic Calculator (C)

A beginner-friendly command-line calculator developed in C for **CodeAlpha C Programming Internship — Task 1 (Basic)**.

## Overview

This program accepts two numbers and an arithmetic operator, then performs the selected operation using a `switch` statement.

## Features

- Addition (`+`)
- Subtraction (`-`)
- Multiplication (`*`)
- Division (`/`)
- Decimal-number support through `double`
- Input validation for numeric values
- Protection against division by zero
- Error message for an unsupported operator

## Concepts demonstrated

- Standard input/output with `<stdio.h>`
- Variables and data types (`double` and `char`)
- `scanf()` and `printf()`
- Arithmetic operators
- `switch`, `case`, `default`, and `break`
- Conditional statements and return codes

## Requirements

- A C compiler, such as GCC
- A terminal or command prompt (or a C IDE such as Code::Blocks or Visual Studio Code configured with a compiler)

## Project files

```text
CodeAlpha_Calculator/
├── README.md
└── CodeAlpla_Basic_Calculator.c
```

## Compile and run

Compile with GCC:

```bash
gcc -std=c11 -Wall -Wextra -pedantic CodeAlpla_Basic_Calculator.c -o calculator
```

Run on Linux or macOS:

```bash
./calculator
```

On Windows with GCC:

```bash
calculator.exe
```

## Example

```text
===== CodeAlpha Basic Calculator =====
Enter first number: 25
Enter operator (+, -, *, /): +
Enter second number: 15
Result: 40.00
Thank you for using the calculator!
```

## Test checklist

- [ ] Addition of two positive numbers
- [ ] Subtraction resulting in a negative number
- [ ] Multiplication
- [ ] Division with a non-zero divisor
- [ ] Division by zero
- [ ] Decimal inputs
- [ ] Unsupported operator
- [ ] Non-numeric input

## Learning references

- [ISO/IEC 9899:2024 — C programming language standard](https://www.iso.org/standard/82075.html)
- [GNU C Manual](https://www.gnu.org/software/gnu-c-manual/gnu-c-manual.html)
- [cppreference: C `switch` statement](https://en.cppreference.com/w/c/language/switch)
- [cppreference: C input/output functions](https://en.cppreference.com/w/c/io)

## Internship task

**Organization:** CodeAlpha  
**Domain:** C Programming  
**Task:** Task 1 — Basic Calculator

---

This is an educational internship project. Review and test the source code with your own compiler before submission.
