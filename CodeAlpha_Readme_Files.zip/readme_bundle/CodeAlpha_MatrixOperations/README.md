# CodeAlpha Matrix Operations (C)

A menu-driven C program implementing **matrix addition, matrix multiplication, and matrix transpose** for **CodeAlpha C Programming Internship — Task 2 (Medium)**.

## Overview

The program uses two-dimensional arrays and separate functions to perform matrix operations. It accepts two matrices from the user, checks whether their dimensions are compatible with the requested operation, and displays the result.

## Features

- Matrix addition
- Matrix multiplication
- Transpose of matrix A
- Transpose of matrix B
- Menu-driven interface that allows more than one operation per run
- Validation of matrix dimensions and numeric input
- Clear messages when matrix dimensions are incompatible
- Support for matrices up to `10 × 10`

## Concepts demonstrated

- Two-dimensional arrays
- Functions and parameters
- Nested `for` loops
- `switch` statements
- Dimension compatibility checks
- Standard input/output with `<stdio.h>`
- Symbolic constants with `#define`

## Requirements

- A C compiler, such as GCC
- A terminal or command prompt (or a C IDE configured with a compiler)

## Project files

```text
CodeAlpha_MatrixOperations/
├── README.md
└── CodeAlpha_MatrixOperations.c
```

## Compile and run

Compile with GCC:

```bash
gcc -std=c11 -Wall -Wextra -pedantic CodeAlpha_MatrixOperations.c -o matrix_operations
```

Run on Linux or macOS:

```bash
./matrix_operations
```

On Windows with GCC:

```bash
matrix_operations.exe
```

## Example

For the following two matrices:

```text
A =        B =
1 2        5 6
3 4        7 8
```

Addition produces:

```text
A + B =
6  8
10 12
```

Transpose of A produces:

```text
Transpose of A =
1 3
2 4
```

For multiplication, the number of columns in A must equal the number of rows in B. For addition, both matrices must have exactly the same dimensions.

## Test checklist

- [ ] Add two matrices with equal dimensions
- [ ] Try addition with unequal dimensions
- [ ] Multiply compatible matrices
- [ ] Try multiplication with incompatible dimensions
- [ ] Transpose a square matrix
- [ ] Transpose a rectangular matrix
- [ ] Enter an invalid dimension
- [ ] Try each menu option and exit

## Learning references

- [ISO/IEC 9899:2024 — C programming language standard](https://www.iso.org/standard/82075.html)
- [ISO C working group WG14](https://open-std.org/jtc1/sc22/wg14/)
- [GNU C manual: Multidimensional arrays](https://www.gnu.org/software/c-intro-and-ref/manual/html_node/Multidimensional-Arrays.html)
- [GNU C manual: Arrays as parameters](https://www.gnu.org/software/c-intro-and-ref/manual/html_node/Arrays-as-Parameters.html)
- [cppreference: C arrays](https://en.cppreference.com/w/c/language/array)

## Internship task

**Organization:** CodeAlpha  
**Domain:** C Programming  
**Task:** Task 2 — Matrix Operations

---

This is an educational internship project. Review and test the source code with your own compiler before submission.
