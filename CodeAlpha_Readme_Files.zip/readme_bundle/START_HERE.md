# README files for the three CodeAlpha C internship tasks

This bundle contains one separate `README.md` for each project, following the repository naming convention from the internship instructions.

## Where each file goes

1. Put `CodeAlpha_Calculator/README.md` in the root of your GitHub repository named `CodeAlpha_Calculator`, next to `CodeAlpla_Basic_Calculator.c`.
2. Put `CodeAlpha_MatrixOperations/README.md` in the root of your GitHub repository named `CodeAlpha_MatrixOperations`, next to `CodeAlpha_MatrixOperations.c`.
3. Put `CodeAlpha_StudentManagementSystem/README.md` in the root of your GitHub repository named `CodeAlpha_StudentManagementSystem`, next to `Student_Management.c`.

Do not upload all three README files into one of the individual repositories. Each README documents only its matching project.

## Upload through the GitHub website

1. Open the matching GitHub repository.
2. Choose **Add file → Upload files**.
3. Upload that project's `.c` source file and its `README.md`.
4. Enter a commit message, such as `Add project source and README`.
5. Select **Commit changes**.

Alternatively, use **Add file → Create new file**, name it `README.md`, paste the contents from the matching file, and commit the change.
